//
//  Helpers.swift
//  FloatingHearts
//
//  Created by Xinzhe Wang on 1/16/18.
//  Copyright © 2018 IntBridge. All rights reserved.
//

import Foundation

extension UIColor {
    
    convenience init(red: Int, green: Int, blue: Int) {
        self.init(red: CGFloat(red)/255.0, green: CGFloat(green)/255.0, blue: CGFloat(blue)/255.0, alpha: 1.0)
    }
    
    convenience init(hex: Int) {
        self.init(red: ((hex >> 16) & 0xFF), green: ((hex >> 8) & 0xFF), blue: (hex & 0xFF))
    }
}

extension Timer {
    
    public class func new(interval: TimeInterval, block: @escaping (() -> Void)) -> Timer {
        let timerActor = TimerActor(block)
        return self.init(timeInterval: interval, target: timerActor, selector: #selector(fire), userInfo: nil, repeats: false)
    }
    
    public static func after(interval: TimeInterval, block: @escaping (() -> Void)) -> Timer {
        let timer = Timer.new(interval: interval, block: block)
        RunLoop.current.add(timer, forMode: RunLoop.Mode.common)
        return timer
    }
}

// MARK: Timer Helpers

//Stripped down extension - similar to SwiftTimer https://github.com/radex/SwiftyTimer
private class TimerActor {
    
    let fireBlock: (() -> Void)
    
    init(_ block: @escaping () -> Void) {
        fireBlock = block
    }
    
    @objc func fire() {
        fireBlock()
    }
}

// MARK: Animaition Helpers

public func spring(duration: TimeInterval, delay: TimeInterval, damping: CGFloat, velocity: CGFloat, animations: @escaping () -> Void) {
    
    UIView.animate(withDuration: duration, delay: delay, usingSpringWithDamping: damping, initialSpringVelocity: velocity, options: [UIView.AnimationOptions.curveEaseOut], animations: {
        animations()
    }, completion: nil)
}

public func animate(duration: TimeInterval, delay: TimeInterval, animations: @escaping () -> Void, completion: @escaping () -> Void) {
    
    UIView.animate(withDuration: duration, delay: delay, options: [], animations: {
        animations()
    }, completion: { finished in
        completion()
    })
}

public func animate(duration: TimeInterval, delay: TimeInterval, animations: @escaping () -> Void) {
    
    UIView.animate(withDuration: duration, delay: delay, options: [], animations: {
        animations()
    }, completion: { finished in
    })
}

// MARK: Math Helpers

//Briefly investigated creating a generic function to accept various numeric types.
//Seems too much work at this stage. For another time...

public func randomNumber(_ cap: Int) -> CGFloat {
    return CGFloat(arc4random_uniform(UInt32(cap)))
}

public func randomNumber(_ cap: CGFloat) -> CGFloat {
    return randomNumber(Int(cap))
}
