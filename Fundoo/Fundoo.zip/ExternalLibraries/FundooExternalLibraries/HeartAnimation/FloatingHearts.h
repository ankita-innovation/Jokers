//
//  FloatingHearts.h
//  FloatingHearts
//
//  Created by Xinzhe Wang on 1/16/18.
//  Copyright © 2018 IntBridge. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FloatingHearts.
FOUNDATION_EXPORT double FloatingHeartsVersionNumber;

//! Project version string for FloatingHearts.
FOUNDATION_EXPORT const unsigned char FloatingHeartsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FloatingHearts/PublicHeader.h>


